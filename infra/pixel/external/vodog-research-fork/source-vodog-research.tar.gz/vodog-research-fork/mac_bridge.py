#!/usr/bin/env python3
"""Host side of the VoDog research PCM bridge.

Pixel connects to 127.0.0.1:8765 via `adb reverse`. This process:
  - plays VOICE_DOWNLINK PCM from the Pixel on the Mac speakers (ffplay)
  - loops a distinct test clip back for Telephony Tx inject

Usage:
  adb -s <ADB_SERIAL> reverse tcp:8765 tcp:8765
  python3 mac_bridge.py
  # then place the cellular call from the Pixel
"""
from __future__ import annotations

import socket
import struct
import subprocess
import sys
import threading
import time
from pathlib import Path

HOST = "127.0.0.1"
PORT = 8765
TYPE_DL = 1
TYPE_UL = 2
RATE = 16000
FRAME = 640  # 20 ms s16le mono
HERE = Path(__file__).resolve().parent
CLIP = HERE.parent / "test-audio" / "mac-tx-test.wav"


def recvall(conn: socket.socket, n: int) -> bytes:
    buf = bytearray()
    while len(buf) < n:
        chunk = conn.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("eof")
        buf.extend(chunk)
    return bytes(buf)


def load_pcm(path: Path) -> bytes:
    cmd = [
        "ffmpeg", "-hide_banner", "-loglevel", "error",
        "-i", str(path),
        "-f", "s16le", "-acodec", "pcm_s16le", "-ac", "1", "-ar", str(RATE),
        "pipe:1",
    ]
    return subprocess.check_output(cmd)


def send_ul(conn: socket.socket, data: bytes) -> None:
    n = len(data)
    conn.sendall(bytes((TYPE_UL, n & 0xFF, (n >> 8) & 0xFF)) + data)


def inject_loop(conn: socket.socket, pcm: bytes, stop: threading.Event) -> None:
    if not pcm:
        return
    i = 0
    t0 = time.monotonic()
    sent = 0
    while not stop.is_set():
        chunk = pcm[i : i + FRAME]
        if len(chunk) < FRAME:
            i = 0
            continue
        i += FRAME
        try:
            send_ul(conn, chunk)
        except OSError:
            break
        sent += FRAME
        due = t0 + (sent / 2) / RATE
        now = time.monotonic()
        if due > now:
            time.sleep(due - now)
    print("inject loop ended", flush=True)


def play_dl(conn: socket.socket, stop: threading.Event) -> None:
    ffplay = subprocess.Popen(
        [
            "ffplay", "-hide_banner", "-loglevel", "error",
            "-nodisp", "-autoexit",
            "-f", "s16le", "-ar", str(RATE), "-ch_layout", "mono",
            "-i", "pipe:0",
        ],
        stdin=subprocess.PIPE,
    )
    stdin = ffplay.stdin
    assert stdin is not None
    try:
        while not stop.is_set():
            hdr = recvall(conn, 3)
            typ, nlo, nhi = hdr[0], hdr[1], hdr[2]
            n = nlo | (nhi << 8)
            data = recvall(conn, n)
            if typ == TYPE_DL:
                stdin.write(data)
                stdin.flush()
    except (ConnectionError, BrokenPipeError, OSError) as e:
        print("play_dl ended:", e, flush=True)
    finally:
        stop.set()
        try:
            stdin.close()
        except OSError:
            pass
        ffplay.wait(timeout=3)


def handle(conn: socket.socket, pcm: bytes) -> None:
    stop = threading.Event()
    inj = threading.Thread(target=inject_loop, args=(conn, pcm, stop), daemon=True)
    inj.start()
    try:
        play_dl(conn, stop)
    finally:
        stop.set()
        try:
            conn.close()
        except OSError:
            pass
        inj.join(timeout=2)


def main() -> int:
    if not CLIP.is_file():
        print("missing", CLIP, file=sys.stderr)
        return 1
    pcm = load_pcm(CLIP)
    print(f"clip {CLIP.name}: {len(pcm)} bytes ({len(pcm)/2/RATE:.1f}s)  listen {HOST}:{PORT}", flush=True)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((HOST, PORT))
        srv.listen(1)
        print("waiting for Pixel (adb reverse tcp:8765 tcp:8765)…", flush=True)
        while True:
            conn, addr = srv.accept()
            conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            print("Pixel connected", addr, flush=True)
            handle(conn, pcm)
            print("call session ended — waiting again", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
