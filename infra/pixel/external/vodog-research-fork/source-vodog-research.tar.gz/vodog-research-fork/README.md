# VoDog research fork

Optional telephony audio research based on [BCP v1.1](https://github.com/chenxiaolong/BCP/tree/0350949cc1a8b83bebc725cf25256b259c61edf9), under GPLv3. See LICENSE and README.upstream.md.

Modifications add privileged downlink capture, Telephony Tx PCM injection, microphone foreground-service support, device-protected preferences and a host PCM bridge. This is a research app, separate from the VoDog gateway. Do not run competing audio injection owners simultaneously.

Build using the included Gradle wrapper with JDK 21 and Android SDK 36: `./gradlew zipDebug`. The host bridge requires Python 3, ffmpeg and ffplay; use `adb -s <ADB_SERIAL> reverse tcp:8765 tcp:8765` and run `python3 mac_bridge.py`. Both bundled WAV files contain a generated one-second 440-Hz tone. Extract the vodog-research-fork and test-audio roots as siblings.
