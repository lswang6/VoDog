package com.chiller3.bcp

import android.util.Log
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * USB `adb reverse` TCP bridge to the Mac.
 * Pixel connects to 127.0.0.1:8765 which adb forwards to the Mac server.
 *
 * Frame: type:u8, n:u16le, data[n]
 *   type 1 = downlink (Pixel → Mac)
 *   type 2 = uplink   (Mac → Pixel)
 */
class CallBridge {
    companion object {
        private const val TAG = "CallBridge"
        const val HOST = "127.0.0.1"
        const val PORT = 8765
        const val TYPE_DL: Byte = 1
        const val TYPE_UL: Byte = 2
    }

    private val running = AtomicBoolean(false)
    private var socket: Socket? = null
    private var out: DataOutputStream? = null
    private val uplink = LinkedBlockingQueue<ByteArray>(64)
    private var reader: Thread? = null

    fun connect(timeoutMs: Int): Boolean {
        return try {
            val s = Socket()
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(HOST, PORT), timeoutMs)
            socket = s
            out = DataOutputStream(s.getOutputStream())
            running.set(true)
            reader = Thread({ readLoop(DataInputStream(s.getInputStream())) }, "CallBridge.reader").also { it.start() }
            Log.i(TAG, "connected to $HOST:$PORT")
            true
        } catch (e: Exception) {
            Log.w(TAG, "connect failed: ${e.message}")
            close()
            false
        }
    }

    fun sendDownlink(buf: ByteArray, n: Int) {
        val o = out ?: return
        if (!running.get() || n <= 0) return
        try {
            synchronized(o) {
                o.writeByte(TYPE_DL.toInt())
                o.writeByte(n and 0xff)
                o.writeByte(n shr 8 and 0xff)
                o.write(buf, 0, n)
                o.flush()
            }
        } catch (e: Exception) {
            Log.w(TAG, "sendDownlink: ${e.message}")
            running.set(false)
        }
    }

    fun pollUplink(timeoutMs: Long): ByteArray? {
        return try {
            uplink.poll(timeoutMs, TimeUnit.MILLISECONDS)
        } catch (_: InterruptedException) {
            null
        }
    }

    fun close() {
        running.set(false)
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        out = null
        uplink.clear()
        reader = null
        Log.i(TAG, "closed")
    }

    private fun readLoop(input: DataInputStream) {
        try {
            while (running.get()) {
                val type = input.readUnsignedByte()
                val n = input.readUnsignedByte() or (input.readUnsignedByte() shl 8)
                if (n <= 0 || n > 8192) {
                    Log.w(TAG, "bad frame type=$type n=$n")
                    break
                }
                val data = ByteArray(n)
                input.readFully(data)
                if (type == TYPE_UL.toInt()) {
                    if (!uplink.offer(data)) {
                        uplink.poll()
                        uplink.offer(data)
                    }
                }
            }
        } catch (e: Exception) {
            if (running.get()) Log.w(TAG, "readLoop: ${e.message}")
        } finally {
            running.set(false)
        }
    }
}
