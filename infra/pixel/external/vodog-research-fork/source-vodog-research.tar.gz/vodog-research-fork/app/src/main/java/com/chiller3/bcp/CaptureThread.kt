package com.chiller3.bcp

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.telecom.Call
import android.util.Log
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.sqrt

/**
 * Capture VOICE_DOWNLINK to a WAV while inject is also running in this process.
 */
class CaptureThread(
    context: Context,
    call: Call,
    private val onPcm: ((ByteArray, Int) -> Unit)? = null,
) : Thread(CaptureThread::class.java.simpleName) {
    private val tag = "${CaptureThread::class.java.simpleName}/${id}"
    private val appContext = context.applicationContext.createDeviceProtectedStorageContext()

    @Volatile private var isCancelled = false

    val outputFile: File = File(appContext.filesDir, "downlink.wav")

    init {
        Log.i(tag, "Created capture thread for call: $call -> $outputFile")
    }

    fun cancel() {
        isCancelled = true
    }

    override fun run() {
        val sampleRate = 16000
        val channelMask = AudioFormat.CHANNEL_IN_MONO
        val encoding = AudioFormat.ENCODING_PCM_16BIT
        val minBuf = AudioRecord.getMinBufferSize(sampleRate, channelMask, encoding)
        if (minBuf <= 0) {
            Log.e(tag, "getMinBufferSize failed: $minBuf")
            return
        }
        val bufSize = minBuf * 4
        val source = MediaRecorder.AudioSource.VOICE_DOWNLINK
        Log.i(tag, "opening AudioRecord source=VOICE_DOWNLINK($source) rate=$sampleRate minBuf=$minBuf")

        val record = try {
            AudioRecord.Builder()
                .setAudioSource(source)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelMask)
                        .setEncoding(encoding)
                        .build()
                )
                .setBufferSizeInBytes(bufSize)
                .build()
        } catch (e: Exception) {
            Log.e(tag, "AudioRecord.Builder failed", e)
            return
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(tag, "AudioRecord not initialized: state=${record.state}")
            record.release()
            return
        }

        outputFile.parentFile?.mkdirs()
        val pcm = ByteArray(bufSize)
        var totalBytes = 0L
        var framesLogged = 0
        var sumSq = 0.0
        var peak = 0
        var silencedHint = 0

        try {
            RandomAccessFile(outputFile, "rw").use { raf ->
                writeWavHeader(raf, sampleRate, 1, 16, 0)
                record.startRecording()
                Log.i(tag, "startRecording recordingState=${record.recordingState} session=${record.audioSessionId}")

                while (!isCancelled) {
                    val n = record.read(pcm, 0, pcm.size)
                    if (n < 0) {
                        Log.e(tag, "AudioRecord.read error: $n")
                        break
                    }
                    if (n == 0) continue
                    raf.write(pcm, 0, n)
                    totalBytes += n
                    try { onPcm?.invoke(pcm, n) } catch (e: Exception) {
                        Log.w(tag, "onPcm: ${e.message}")
                    }

                    var i = 0
                    var localPeak = 0
                    var localSq = 0.0
                    while (i + 1 < n) {
                        val s = (pcm[i].toInt() and 0xff) or (pcm[i + 1].toInt() shl 8)
                        val v = s.toShort().toInt()
                        localSq += v.toDouble() * v
                        val a = if (v < 0) -v else v
                        if (a > localPeak) localPeak = a
                        i += 2
                    }
                    sumSq += localSq
                    if (localPeak > peak) peak = localPeak
                    if (localPeak < 8) silencedHint++
                    framesLogged++
                    if (framesLogged % 50 == 0) {
                        val samples = (n / 2).coerceAtLeast(1)
                        val rms = sqrt(localSq / samples)
                        Log.i(tag, "cap rms=$rms peak=$localPeak bytes=$totalBytes silencedFrames=$silencedHint/$framesLogged")
                    }
                }

                val dataSize = totalBytes.toInt()
                raf.seek(0)
                writeWavHeader(raf, sampleRate, 1, 16, dataSize)
            }
        } catch (e: Exception) {
            Log.e(tag, "capture failed", e)
        } finally {
            try { record.stop() } catch (_: Exception) {}
            record.release()
            val samples = (totalBytes / 2).coerceAtLeast(1)
            val rms = sqrt(sumSq / samples)
            Log.i(tag, "capture done file=$outputFile bytes=$totalBytes rms=$rms peak=$peak silenced=$silencedHint/$framesLogged")
        }
    }

    private fun writeWavHeader(raf: RandomAccessFile, rate: Int, channels: Int, bits: Int, dataBytes: Int) {
        val byteRate = rate * channels * bits / 8
        val blockAlign = channels * bits / 8
        raf.writeBytes("RIFF")
        writeIntLE(raf, 36 + dataBytes)
        raf.writeBytes("WAVE")
        raf.writeBytes("fmt ")
        writeIntLE(raf, 16)
        writeShortLE(raf, 1)
        writeShortLE(raf, channels)
        writeIntLE(raf, rate)
        writeIntLE(raf, byteRate)
        writeShortLE(raf, blockAlign)
        writeShortLE(raf, bits)
        raf.writeBytes("data")
        writeIntLE(raf, dataBytes)
    }

    private fun writeIntLE(raf: RandomAccessFile, v: Int) {
        raf.write(v and 0xff)
        raf.write(v shr 8 and 0xff)
        raf.write(v shr 16 and 0xff)
        raf.write(v shr 24 and 0xff)
    }

    private fun writeShortLE(raf: RandomAccessFile, v: Int) {
        raf.write(v and 0xff)
        raf.write(v shr 8 and 0xff)
    }
}
