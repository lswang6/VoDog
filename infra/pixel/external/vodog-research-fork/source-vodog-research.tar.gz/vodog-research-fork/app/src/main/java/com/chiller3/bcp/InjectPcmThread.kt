package com.chiller3.bcp

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.telecom.Call
import android.util.Log

/** Play 16 kHz s16le mono PCM from [CallBridge] onto Telephony Tx. */
class InjectPcmThread(
    private val context: Context,
    private val bridge: CallBridge,
    call: Call,
) : Thread(InjectPcmThread::class.java.simpleName) {
    private val tag = "${InjectPcmThread::class.java.simpleName}/${id}"

    @Volatile private var isCancelled = false

    init {
        Log.i(tag, "Created inject thread for $call")
    }

    fun cancel() {
        isCancelled = true
        interrupt()
    }

    override fun run() {
        val audioManager = context.getSystemService(AudioManager::class.java)
        val outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val telephony = outputs.find { it.type == AudioDeviceInfo.TYPE_TELEPHONY }
        if (telephony == null) {
            Log.e(tag, "no TYPE_TELEPHONY")
            return
        }
        val sampleRate = 16000
        val channelMask = AudioFormat.CHANNEL_OUT_MONO
        val encoding = AudioFormat.ENCODING_PCM_16BIT
        val minBuf = AudioTrack.getMinBufferSize(sampleRate, channelMask, encoding)
        val format = AudioFormat.Builder()
            .setSampleRate(sampleRate)
            .setChannelMask(channelMask)
            .setEncoding(encoding)
            .build()
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
            .build()
        val track = AudioTrack.Builder()
            .setBufferSizeInBytes(minBuf)
            .setAudioAttributes(attributes)
            .setAudioFormat(format)
            .build()
        if (!track.setPreferredDevice(telephony)) {
            Log.e(tag, "setPreferredDevice failed")
            track.release()
            return
        }
        track.play()
        Log.i(tag, "playing routed=${track.routedDevice?.type} session=${track.audioSessionId}")
        val silence = ByteArray(640)
        var frames = 0
        try {
            while (!isCancelled) {
                val pcm = bridge.pollUplink(20) ?: silence
                val n = track.write(pcm, 0, pcm.size)
                if (n < 0) {
                    Log.e(tag, "AudioTrack.write $n")
                    break
                }
                frames++
                if (frames % 50 == 0) {
                    Log.i(tag, "inject frames=$frames last=${pcm.size} routed=${track.routedDevice?.type}")
                }
            }
        } catch (e: Exception) {
            if (!isCancelled) Log.e(tag, "inject failed", e)
        } finally {
            try { track.stop() } catch (_: Exception) {}
            track.release()
            Log.i(tag, "inject done frames=$frames")
        }
    }
}
