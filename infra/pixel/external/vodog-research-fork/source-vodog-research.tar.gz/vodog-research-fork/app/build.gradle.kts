plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.chiller3.bcp"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.chiller3.bcp"
        minSdk = 28
        targetSdk = 36
        versionCode = 201105
        versionName = "1.1-vodog-research"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "PROJECT_URL_AT_COMMIT", "\"https://github.com/chenxiaolong/BCP\"")
    }
    signingConfigs {
        create("release") {
            val keystore = System.getenv("RELEASE_KEYSTORE")
            storeFile = if (keystore != null) { File(keystore) } else { null }
            storePassword = System.getenv("RELEASE_KEYSTORE_PASSPHRASE")
            keyAlias = System.getenv("RELEASE_KEY_ALIAS")
            keyPassword = System.getenv("RELEASE_KEY_PASSPHRASE")
        }
    }
    buildTypes {
        getByName("debug") {
            isMinifyEnabled = false
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.preference:preference-ktx:1.2.1")
    implementation("com.google.android.material:material:1.12.0")
}

android.applicationVariants.all {
    val variant = this
    val capitalized = variant.name.replaceFirstChar { it.uppercase() }
    val extraDir = File(layout.buildDirectory.get().asFile, "extra")
    val variantDir = File(extraDir, variant.name)

    val moduleProp = tasks.register("moduleProp${capitalized}") {
        val outputFile = File(variantDir, "module.prop")
        outputs.file(outputFile)
        doLast {
            outputFile.parentFile.mkdirs()
            outputFile.writeText(
                """
                id=${variant.applicationId}
                name=BCP
                version=v${variant.versionName}
                versionCode=${variant.versionCode}
                author=chenxiaolong
                description=Basic Call Player (Android 17 Pixel test fork)
                """.trimIndent() + "\n"
            )
        }
    }

    val permissionsXml = tasks.register("permissionsXml${capitalized}") {
        val outputFile = File(variantDir, "privapp-permissions-${variant.applicationId}.xml")
        outputs.file(outputFile)
        doLast {
            outputFile.parentFile.mkdirs()
            outputFile.writeText(
                """
                <?xml version="1.0" encoding="utf-8"?>
                <permissions>
                    <privapp-permissions package="${variant.applicationId}">
                        <permission name="android.permission.CONTROL_INCALL_EXPERIENCE" />
                        <permission name="android.permission.MODIFY_PHONE_STATE" />
                        <permission name="android.permission.CAPTURE_AUDIO_OUTPUT" />
                    </privapp-permissions>
                </permissions>
                """.trimIndent() + "\n"
            )
        }
    }

    tasks.register<Zip>("zip${capitalized}") {
        archiveFileName.set("BCP-${variant.versionName}-${variant.name}.zip")
        destinationDirectory.set(File(project.layout.buildDirectory.get().asFile, "distributions/${variant.name}"))
        isPreserveFileTimestamps = false
        isReproducibleFileOrder = true
        dependsOn(variant.assembleProvider, moduleProp, permissionsXml)

        from(moduleProp.get().outputs)
        from(permissionsXml.get().outputs) {
            into("system/etc/permissions")
        }
        from(variant.outputs.map { it.outputFile }) {
            into("system/priv-app/${variant.applicationId}")
        }
        val magiskDir = File(projectDir, "magisk")
        for (script in arrayOf("update-binary", "updater-script")) {
            from(File(magiskDir, script)) {
                into("META-INF/com/google/android")
            }
        }
        from(File(rootDir, "LICENSE"))
        from(File(rootDir, "README.md"))
    }
}
