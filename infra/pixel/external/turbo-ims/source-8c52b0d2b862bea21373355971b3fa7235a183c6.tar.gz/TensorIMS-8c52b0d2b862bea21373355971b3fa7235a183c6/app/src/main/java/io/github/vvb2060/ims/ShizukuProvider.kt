package io.github.vvb2060.ims

import android.app.IActivityManager
import android.app.IInstrumentationWatcher
import android.app.UiAutomationConnection
import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import android.os.ServiceManager
import android.telephony.SubscriptionInfo
import android.util.Log
import io.github.vvb2060.ims.model.ImsCapabilityStatus
import io.github.vvb2060.ims.model.SimSelection
import io.github.vvb2060.ims.privileged.BrokerInstrumentation
import io.github.vvb2060.ims.privileged.isCarrierConfigPermissionError
import io.github.vvb2060.ims.privileged.ImsCapabilityReader
import io.github.vvb2060.ims.privileged.ImsModifier
import io.github.vvb2060.ims.privileged.ImsResetter
import io.github.vvb2060.ims.privileged.SimReader
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import org.lsposed.hiddenapibypass.LSPass
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.ShizukuProvider

class ShizukuProvider : ShizukuProvider() {
    override fun onCreate(): Boolean {
        LSPass.setHiddenApiExemptions("")
        // 不再自动触发，只在用户手动点击"应用配置"时才执行
        return super.onCreate()
    }

    companion object {
        private const val TAG = "ShizukuProvider"
        private const val INSTRUMENTATION_TIMEOUT_MS = 15_000L

        suspend fun overrideImsConfig(context: Context, data: Bundle): String? {
            val primaryArgs = Bundle(data)
            val result = startInstrumentation(context, ImsModifier::class.java, primaryArgs, true)
            if (result == null) {
                Log.w(TAG, "overrideImsConfig: failed with empty result")
                return tryOverrideWithBroker(context, data, "failed with empty result")
            }
            if (result.getBoolean(ImsModifier.BUNDLE_RESULT)) {
                return null
            }
            val msg = result.getString(ImsModifier.BUNDLE_RESULT_MSG) ?: "unknown error"
            // Retry via broker when persistent override is restricted or result is empty.
            return tryOverrideWithBroker(context, data, msg)
        }

        private suspend fun tryOverrideWithBroker(
            context: Context,
            data: Bundle,
            msg: String,
        ): String? {
            if (!shouldRetryWithBroker(msg)) {
                return msg
            }
            val brokerArgs = Bundle(data)
            val brokerResult =
                startInstrumentation(context, BrokerInstrumentation::class.java, brokerArgs, true)
            if (brokerResult == null) {
                return "$msg\n\nBroker: failed with empty result"
            }
            if (brokerResult.getBoolean(ImsModifier.BUNDLE_RESULT)) {
                return null
            }
            val brokerMsg =
                brokerResult.getString(ImsModifier.BUNDLE_RESULT_MSG) ?: "unknown error"
            return "$msg\n\nBroker: $brokerMsg"
        }

        private fun shouldRetryWithBroker(msg: String): Boolean {
            return isCarrierConfigPermissionError(msg) ||
                    msg.contains("failed with empty result", ignoreCase = true)
        }

        suspend fun readImsCapabilities(context: Context, subId: Int): ImsCapabilityStatus? {
            val args = Bundle().apply {
                putInt(ImsCapabilityReader.BUNDLE_SELECT_SIM_ID, subId)
            }
            val result = startInstrumentation(context, ImsCapabilityReader::class.java, args, true)
            if (result == null) {
                Log.w(TAG, "readImsCapabilities: failed with empty result")
                return null
            }
            if (result.getString(ImsCapabilityReader.BUNDLE_RESULT_MSG) != null) {
                Log.w(TAG, "readImsCapabilities: ${result.getString(ImsCapabilityReader.BUNDLE_RESULT_MSG)}")
                return null
            }
            return ImsCapabilityStatus(
                isRegistered = result.getBoolean(ImsCapabilityReader.BUNDLE_IMS_REGISTERED),
                isVolteAvailable = result.getBoolean(ImsCapabilityReader.BUNDLE_VOLTE),
                isVoWifiAvailable = result.getBoolean(ImsCapabilityReader.BUNDLE_VOWIFI),
                isVoNrAvailable = result.getBoolean(ImsCapabilityReader.BUNDLE_VONR),
                isVtAvailable = result.getBoolean(ImsCapabilityReader.BUNDLE_VT),
                isNrNsaAvailable = result.getBoolean(ImsCapabilityReader.BUNDLE_NR_NSA),
                isNrSaAvailable = result.getBoolean(ImsCapabilityReader.BUNDLE_NR_SA),
            )
        }

        suspend fun resetIms(context: Context, subId: Int): String? {
            val args = Bundle().apply {
                putInt(ImsResetter.BUNDLE_SELECT_SIM_ID, subId)
            }
            val result = startInstrumentation(context, ImsResetter::class.java, args, true)
            if (result == null) return "Unknown error"
            return result.getString(ImsResetter.BUNDLE_RESULT_MSG)
        }

        suspend fun readSimInfoList(context: Context): List<SimSelection> {
            val result = startInstrumentation(context, SimReader::class.java, null, true)
            if (result == null) {
                Log.w(TAG, "readSimInfoList: failed with empty result")
                return emptyList()
            }
            val subList =
                result.getParcelableArrayList(SimReader.BUNDLE_RESULT, SubscriptionInfo::class.java)
            val resultList = subList?.map {
                SimSelection(
                    it.subscriptionId,
                    it.displayName.toString(),
                    it.carrierName.toString(),
                    it.simSlotIndex,
                )
            } ?: emptyList()
            return resultList
        }

        private suspend fun startInstrumentation(
            context: Context,
            cls: Class<*>,
            args: Bundle?,
            receiveResult: Boolean,
        ): Bundle? {
            val deferredResult = CompletableDeferred<Bundle?>()
            var watcher: IInstrumentationWatcher.Stub? = null
            if (receiveResult) {
                watcher = object : IInstrumentationWatcher.Stub() {
                    override fun instrumentationStatus(
                        name: ComponentName?,
                        resultCode: Int,
                        results: Bundle?
                    ) {
                    }

                    override fun instrumentationFinished(
                        name: ComponentName?,
                        resultCode: Int,
                        results: Bundle?
                    ) {
                        deferredResult.complete(results)
                    }
                }
            }

            val binder = ServiceManager.getService(Context.ACTIVITY_SERVICE)
            val am = IActivityManager.Stub.asInterface(ShizukuBinderWrapper(binder))
            val name = ComponentName(context, cls)
            val flags = 8 // ActivityManager.INSTR_FLAG_NO_RESTART
            val connection = UiAutomationConnection()
            try {
                Log.d(TAG, "startInstrumentation: call with component: $name")
                val started = am.startInstrumentation(
                    name,
                    null,
                    flags,
                    args,
                    watcher,
                    connection,
                    0,
                    null
                )
                if (!started) {
                    Log.e(TAG, "instrumentation start rejected for component: $name")
                    return null
                }
                Log.i(TAG, "instrumentation started successfully")
                if (receiveResult) {
                    val result = withTimeoutOrNull(INSTRUMENTATION_TIMEOUT_MS) {
                        deferredResult.await()
                    }
                    if (result == null) {
                        Log.e(TAG, "instrumentation result timeout for component: $name")
                    }
                    return result
                }
                return null
            } catch (e: Exception) {
                Log.e(TAG, "failed to start instrumentation", e)
                return null
            }
        }
    }
}
