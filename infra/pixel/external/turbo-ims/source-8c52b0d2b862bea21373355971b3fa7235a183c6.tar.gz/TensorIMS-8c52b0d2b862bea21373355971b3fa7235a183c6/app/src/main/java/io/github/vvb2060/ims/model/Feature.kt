package io.github.vvb2060.ims.model

import androidx.compose.runtime.Immutable
import io.github.vvb2060.ims.R

enum class Feature(
    val valueType: FeatureValueType,
    val showTitleRes: Int,
    val showDescriptionRes: Int,
    val defaultValue: Any,
) {
    CARRIER_NAME(
        FeatureValueType.STRING,
        R.string.carrier_name,
        R.string.carrier_name_desc,
        "",
    ),
    IMS_USER_AGENT(
        FeatureValueType.STRING,
        R.string.ims_user_agent,
        R.string.ims_user_agent_desc,
        "",
    ),
    VOLTE(
        FeatureValueType.BOOLEAN,
        R.string.volte,
        R.string.volte_desc,
        true,
    ),
    VOWIFI(
        FeatureValueType.BOOLEAN,
        R.string.vowifi,
        R.string.vowifi_desc,
        true,
    ),
    VOWIFI_ROAMING(
        FeatureValueType.BOOLEAN,
        R.string.vowifi_roaming,
        R.string.vowifi_roaming_desc,
        false,
    ),
    VT(
        FeatureValueType.BOOLEAN,
        R.string.vt,
        R.string.vt_desc,
        true,
    ),
    VONR(
        FeatureValueType.BOOLEAN,
        R.string.vonr,
        R.string.vonr_desc,
        true,
    ),
    CROSS_SIM(
        FeatureValueType.BOOLEAN,
        R.string.cross_sim,
        R.string.cross_sim_desc,
        true,
    ),
    UT(
        FeatureValueType.BOOLEAN,
        R.string.ut,
        R.string.ut_desc,
        true,
    ),
    FIVE_G_NR(
        FeatureValueType.BOOLEAN,
        R.string._5g_nr,
        R.string._5g_nr_desc,
        true,
    ),
    FIVE_G_THRESHOLDS(
        FeatureValueType.BOOLEAN,
        R.string._5g_thresholds,
        R.string._5g_thresholds_desc,
        true,
    ),
    FIVE_G_PLUS_ICON(
        FeatureValueType.BOOLEAN,
        R.string._5g_plus_icon,
        R.string._5g_plus_icon_desc,
        true,
    ),
    SHOW_4G_FOR_LTE(
        FeatureValueType.BOOLEAN,
        R.string.show_4g_for_lte,
        R.string.show_4g_for_lte_desc,
        false,
    )
}

enum class FeatureValueType {
    BOOLEAN, STRING,
}

@Immutable
data class FeatureValue(
    val data: Any,
    val valueType: FeatureValueType,
)